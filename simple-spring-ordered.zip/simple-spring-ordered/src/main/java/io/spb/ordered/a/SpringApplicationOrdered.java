package io.spb.ordered.a;

import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import io.spb.ordered.a.config.StudentConfig;
import io.spb.ordered.a.service.IService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
@RequiredArgsConstructor
@EnableAspectJAutoProxy()
public class SpringApplicationOrdered implements CommandLineRunner {

	public static void main(String[] args) {
//		System.setProperty("spring.devtools.restart.enabled", "false");

		SpringApplication.run(SpringApplicationOrdered.class, args);

	}

	private final List<IService> serviceList;
	private final StudentConfig studentConfig;

	@Override
	public void run(String... args) throws Exception {

		log.info("Finally I ran...");
		serviceList.forEach(s -> {
			s.serve();
		});
		log.info("Student config "+studentConfig);
	}

}

