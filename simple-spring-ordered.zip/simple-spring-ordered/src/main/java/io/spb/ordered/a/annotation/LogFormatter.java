package io.spb.ordered.a.annotation;

import org.aspectj.lang.reflect.MethodSignature;

public class LogFormatter {
	public  String format(MethodSignature methodSignature ,Object result) {
		return String.valueOf(methodSignature.getDeclaringTypeName()+" :: "+methodSignature.getName()+"[] :: "+ result);
	}
}
