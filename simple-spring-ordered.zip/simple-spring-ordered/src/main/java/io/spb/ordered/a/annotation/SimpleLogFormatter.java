package io.spb.ordered.a.annotation;

import org.aspectj.lang.reflect.MethodSignature;

public class SimpleLogFormatter extends LogFormatter {

	@Override
	public String format(MethodSignature methodSignature, Object result) {
		
		return methodSignature.getName()+"---->"+result;
	}

	

}
