package io.spb.ordered.a.aspect;

import java.lang.reflect.Method;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import io.spb.ordered.a.annotation.LogExecution;
import lombok.extern.slf4j.Slf4j;

@Component
@Aspect
@Slf4j
public class LoggingAspect {

	@Around("@annotation(io.spb.ordered.a.annotation.LogExecution)")
	public Object aroundMethodExecution(ProceedingJoinPoint joinPoint) throws Throwable {
		long start = System.currentTimeMillis();

		Object result = joinPoint.proceed();
		Method method = ((MethodSignature) joinPoint.getSignature()).getMethod();
		System.out.println(method);
		LogExecution annotation = method.getAnnotation(LogExecution.class);

		long executionTime = System.currentTimeMillis() - start;
//		String msg = joinPoint.getSignature() + " executed in " + executionTime + "ms"+" returns "+(annotation.logResult()? result:"");
		String msg=(String) annotation.formatter().getDeclaredMethod("format",MethodSignature.class,Object.class ).invoke(annotation.formatter().newInstance(), (MethodSignature)joinPoint.getSignature(),result);
		switch (annotation.level()) {

		case "info":
			log.info(msg);
			break;
		case "error":
			log.error(msg);
			break;
		case "debug":

		default:
			log.debug(msg);

		}

		return result;
	}
}
