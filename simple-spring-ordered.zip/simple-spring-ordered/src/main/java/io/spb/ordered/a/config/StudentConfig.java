package io.spb.ordered.a.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;
import lombok.ToString;
@Configuration
@ConfigurationProperties(prefix = "com.soham")
@Data
@ToString(includeFieldNames = true)
public class StudentConfig {

	private String name;
	private int rank;
	private int marks;
}
