package io.spb.ordered.a.service;

import org.springframework.core.Ordered;

public interface IService extends Ordered{

	default void serve() {
		System.err.println("I am "+getClass().getName());
	}
}
