package io.spb.ordered.a.service.impl;

import java.time.LocalDateTime;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

import io.spb.ordered.a.annotation.LogExecution;
import io.spb.ordered.a.service.IService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Order(value = Ordered.HIGHEST_PRECEDENCE)
public class PlaneServiceImpl implements IService {

	
	
	public PlaneServiceImpl() {
		try {
			TimeUnit.SECONDS.sleep(4);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	@Override
	public void serve() {
		log.info("Hamba");
		someMethod("Soham", 940);
	}

	@LogExecution(logResult = true,level ="error",logParams = true)
	public Object someMethod(String x,int y) {
		try {
			TimeUnit.SECONDS.sleep(3);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		return "Welcome "+x+" your marks: "+y+" "+LocalDateTime.now();
	}
	
	@PostConstruct
	@LogExecution(logResult = true)
	public void postConstruct() {
		log.info("postConstruct "+getClass().getName());
	}

	@Override
	
	public int getOrder() {
		// TODO Auto-generated method stub
		return Ordered.HIGHEST_PRECEDENCE;
	}

}
