package io.spb.ordered.a.service.impl;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;

import io.spb.ordered.a.service.IService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class RocketServiceImpl implements IService {

	@PostConstruct
	public void postConstruct() {
		log.info("postConstruct "+getClass().getName());
	}

	@Override
	public int getOrder() {
		// TODO Auto-generated method stub
		return 50;
	}

}
